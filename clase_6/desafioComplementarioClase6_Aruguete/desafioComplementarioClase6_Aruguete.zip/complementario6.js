

const arrayNumeros = [5, 1, 4, 25, 475, 3, 8, 9, 8];

console.log('Array: '+arrayNumeros);

console.log('Array ordenado: '+arrayNumeros.sort((a,b) => a-b));

